import React, { createContext, useState, useEffect, useContext } from 'react';

// Create the context
const TaskContext = createContext();

// Create a provider component
export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterDueDate, setFilterDueDate] = useState('');

  // Load initial data
  useEffect(() => {
    const mockTasks = [
      { id: 1, title: 'Interview with Design Team', dueDate: '2024-12-19', status: 'TO-DO', category: 'Work' },
      { id: 2, title: 'Team Meeting', dueDate: '2024-12-30', status: 'TO-DO', category: 'Personal' },
      { id: 3, title: 'Design a Dashboard page along with wireframes', dueDate: '2024-12-31', status: 'TO-DO', category: 'Work' },
      { id: 4, title: 'Morning Workout', dueDate: '2024-12-19', status: 'IN-PROGRESS', category: 'Work' },
      { id: 5, title: 'Code Review', dueDate: '2024-12-19', status: 'IN-PROGRESS', category: 'Personal' },
      { id: 6, title: 'Update Task Tracker', dueDate: '2024-12-25', status: 'COMPLETED', category: 'Work' },
      { id: 7, title: 'Develop Login Authentication', dueDate: '2024-12-22', status: 'IN-PROGRESS', category: 'Work' },
      { id: 8, title: 'Create Marketing Campaign Plan', dueDate: '2024-12-18', status: 'IN-PROGRESS', category: 'Work' },
      { id: 9, title: 'Test API Integration', dueDate: '2024-12-12', status: 'IN-PROGRESS', category: 'Work' },
      { id: 10, title: 'Update Documentation for Release', dueDate: '2024-12-10', status: 'IN-PROGRESS', category: 'Work' },
      { id: 11, title: 'Resolve Bugs in Payment Gateway', dueDate: '2024-12-02', status: 'IN-PROGRESS', category: 'Work' },
      { id: 12, title: 'Submit Project Proposal', dueDate: '2024-12-19', status: 'COMPLETED', category: 'Work' },
      { id: 13, title: 'Birthday Gift Shopping', dueDate: '2024-12-19', status: 'COMPLETED', category: 'Personal' },
      { id: 14, title: 'Client Presentation', dueDate: '2024-12-25', status: 'COMPLETED', category: 'Work' },
    ];
    setTasks(mockTasks);
  }, []);

  // Task operations
  // In TaskContext.js, update the addTask and updateTask functions

const addTask = (newTask) => {
  const task = {
    id: Date.now(),
    title: newTask.title,
    description: newTask.description || '', // Add description field
    dueDate: newTask.dueDate || '',
    status: newTask.status || 'TO-DO',
    category: newTask.category || 'Work'
  };
  setTasks([...tasks, task]);
  return task;
};

const updateTask = (updatedTask) => {
  setTasks(tasks.map(task => 
    task.id === updatedTask.id ? {
      ...task,
      title: updatedTask.title,
      description: updatedTask.description, // Include description
      dueDate: updatedTask.dueDate,
      status: updatedTask.status,
      category: updatedTask.category
    } : task
  ));
};

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const changeTaskStatus = (taskId, newStatus) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  // Filter tasks
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory ? task.category === filterCategory : true;
    
    let matchesDueDate = true;
    if (filterDueDate) {
      const dueDate = new Date(task.dueDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (filterDueDate === 'Today') {
        const taskDate = new Date(task.dueDate);
        taskDate.setHours(0, 0, 0, 0);
        matchesDueDate = taskDate.getTime() === today.getTime();
      } else if (filterDueDate === 'This Week') {
        const taskDate = new Date(task.dueDate);
        const dayOfWeek = today.getDay();
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - dayOfWeek);
        startOfWeek.setHours(0, 0, 0, 0);
        
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6);
        endOfWeek.setHours(23, 59, 59, 999);
        
        matchesDueDate = taskDate >= startOfWeek && taskDate <= endOfWeek;
      } else if (filterDueDate === 'This Month') {
        const taskDate = new Date(task.dueDate);
        matchesDueDate = 
          taskDate.getMonth() === today.getMonth() && 
          taskDate.getFullYear() === today.getFullYear();
      }
    }
    
    return matchesSearch && matchesCategory && matchesDueDate;
  });

  // Group tasks by status
  const groupedTasks = {
    'TO-DO': filteredTasks.filter(task => task.status === 'TO-DO'),
    'IN-PROGRESS': filteredTasks.filter(task => task.status === 'IN-PROGRESS'),
    'COMPLETED': filteredTasks.filter(task => task.status === 'COMPLETED')
  };

  return (
    <TaskContext.Provider value={{
      tasks,
      filteredTasks,
      groupedTasks,
      searchQuery,
      setSearchQuery,
      filterCategory,
      setFilterCategory,
      filterDueDate,
      setFilterDueDate,
      addTask,
      updateTask,
      deleteTask,
      changeTaskStatus
    }}>
      {children}
    </TaskContext.Provider>
  );
};

// Custom hook to use the task context
export const useTasks = () => {
  const context = useContext(TaskContext);
  if (!context) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
};