// src/components/TaskModal.jsx
import React, { useState, useEffect } from 'react';
import { useTasks } from '../context/TaskContext';
import '../styles/TaskModal.css';

const TaskModal = ({ isOpen, onClose, task = null, mode = 'create' }) => {
  const { addTask, updateTask } = useTasks();
  const [taskData, setTaskData] = useState({
    title: '',
    description: '',
    dueDate: '',
    status: 'TO-DO',
    category: 'Work'
  });
  const [attachments, setAttachments] = useState([]);

  // Initialize form with task data if editing
  useEffect(() => {
    if (task && mode === 'edit') {
      setTaskData({
        id: task.id,
        title: task.title || '',
        description: task.description || '',
        dueDate: task.dueDate || '',
        status: task.status || 'TO-DO',
        category: task.category || 'Work'
      });
    } else {
      // Reset form for create mode
      setTaskData({
        title: '',
        description: '',
        dueDate: '',
        status: 'TO-DO',
        category: 'Work'
      });
    }
  }, [task, mode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTaskData({ ...taskData, [name]: value });
  };

  const handleSubmit = () => {
    if (!taskData.title.trim()) return;

    if (mode === 'edit' && task) {
      updateTask(taskData);
    } else {
      addTask(taskData);
    }
    onClose();
  };

  const handleAttachmentUpload = (e) => {
    // In a real app, you would handle file uploads here
    const files = Array.from(e.target.files);
    setAttachments([...attachments, ...files]);
  };

  const removeAttachment = (index) => {
    const newAttachments = [...attachments];
    newAttachments.splice(index, 1);
    setAttachments(newAttachments);
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="task-modal">
        <div className="modal-header">
          <h2>{mode === 'create' ? 'Create Task' : 'Edit Task'}</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          <div className="form-group">
            <input
              type="text"
              name="title"
              placeholder="Task title"
              value={taskData.title}
              onChange={handleChange}
              className="task-title-input"
            />
          </div>
          
          <div className="form-group">
            <label>Description</label>
            <div className="rich-text-toolbar">
              {/* <button><i className="fas fa-bold"></i></button>
              <button><i className="fas fa-italic"></i></button>
              <button><i className="fas fa-underline"></i></button>
              <button><i className="fas fa-list"></i></button> */}
            </div>
            <textarea
              name="description"
              placeholder="Description"
              value={taskData.description}
              onChange={handleChange}
              className="task-description-input"
            />
            <div className="character-count">{taskData.description.length} / 500 characters</div>
          </div>
          
          <div className="form-row">
            <div className="form-group">
              <label>Task Category</label>
              <select 
                name="category"
                value={taskData.category}
                onChange={handleChange}
              >
                <option value="Work">Work</option>
                <option value="Personal">Personal</option>
              </select>
            </div>
            
            <div className="form-group">
              <label>Due on</label>
              <div className="date-input-wrapper">
                <input 
                  type="date" 
                  name="dueDate"
                  value={taskData.dueDate}
                  onChange={handleChange}
                />
                <i className="fas fa-calendar"></i>
              </div>
            </div>
            
            <div className="form-group">
              <label>Task Status</label>
              <select 
                name="status"
                value={taskData.status}
                onChange={handleChange}
              >
                <option value="TO-DO">TO-DO</option>
                <option value="IN-PROGRESS">IN-PROGRESS</option>
                <option value="COMPLETED">COMPLETED</option>
              </select>
            </div>
          </div>
          
          <div className="form-group">
            <label>Attachment</label>
            <div className="attachment-area">
              {attachments.map((file, index) => (
                <div key={index} className="attachment-chip">
                  <span>{file.name}</span>
                  <button onClick={() => removeAttachment(index)}>×</button>
                </div>
              ))}
              <div className="upload-prompt">
                Drop your files here or <button className="upload-link">upload</button>
                <input 
                  type="file" 
                  multiple 
                  onChange={handleAttachmentUpload} 
                  style={{ display: 'none' }}
                  id="file-upload"
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="modal-footer">
          <button className="cancel-btn" onClick={onClose}>CANCEL</button>
          <button className="submit-btn" onClick={handleSubmit}>
            {mode === 'create' ? 'CREATE' : 'UPDATE'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskModal;